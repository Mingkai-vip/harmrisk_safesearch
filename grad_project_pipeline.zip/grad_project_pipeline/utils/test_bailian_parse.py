"""
=============================================================================
测试阿里云百炼（通义千问）大模型结构化输出兼容性
=============================================================================

【目标验证】
    1. 兼容模式调用：测试能否通过 compatible-mode 端点调用通义千问 API。
    2. Parse 接口支持：测试 `client.beta.chat.completions.parse` 的可用性。
    3. Pydantic 约束：验证大模型是否严格遵循传入的 Pydantic BaseModel (JSON Schema) 生成输出。

【输入数据】
    - System 角色提示: "You are a helpful math tutor."
    - User   提问内容: "solve 8x + 31 = 2"

【期望输出】
    - 输出形式:
        严格的 `MathReasoning` 数据结构对象，拒绝任何冗余的自然语言包装。
    - 数据结构:
        {
            "steps": [
                {"explanation": "Subtract 31 from both sides", "output": "8x = 2 - 31"},
                {"explanation": "Simplify the right side",     "output": "8x = -29"},
                {"explanation": "Divide both sides by 8",      "output": "x = -29/8"}
            ],
            "final_answer": "x = -29/8"
        }
=============================================================================
"""

import sys
# 打印启动提示到标准错误流，方便调试
print("STARTING SCRIPT", file=sys.stderr)
import os
# 重新配置标准输出编码为 UTF-8，防止控制台输出中文或特殊字符时报错
sys.stdout.reconfigure(encoding='utf-8')

from dotenv import load_dotenv
from openai import OpenAI
from pydantic import BaseModel

# 加载 .env 文件中的环境变量（如 OPENAI_API_KEY）
load_dotenv()

# 初始化 OpenAI 客户端，将其指向阿里云百炼的兼容端点
client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1"
)

# 定义解题步骤的结构化模型
class Step(BaseModel):
    explanation: str  # 步骤解释
    output: str       # 该步骤的数学推导或中间结果

# 定义最终回答的结构化模型
class MathReasoning(BaseModel):
    steps: list[Step] # 步骤列表
    final_answer: str # 最终计算答案

try:
    # 调用大模型并强制要求其按照 MathReasoning 结构输出
    completion = client.beta.chat.completions.parse(
        model="qwen-plus", # 使用通义千问模型
        messages=[
            {"role": "system", "content": "You are a helpful math tutor."},
            {"role": "user", "content": "solve 8x + 31 = 2"}
        ],
        response_format=MathReasoning, # 传入 Pydantic 模型作为输出格式
    )
    print("Success!")
    # 直接获取解析后的 Pydantic 对象并打印
    print(completion.choices[0].message.parsed)
except Exception as e:
    print(f"Error: {e}")
