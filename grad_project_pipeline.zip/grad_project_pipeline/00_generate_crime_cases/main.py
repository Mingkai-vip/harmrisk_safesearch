#!/usr/bin/env python3
"""
阶段一入口：犯罪测试用例生成（独立版）
使用本目录内的配置与 Prompt 模板批量生成测试用例。

运行方式:
    python grad_project_pipeline/00_generate_crime_cases/main.py
    python grad_project_pipeline/00_generate_crime_cases/main.py --risks "Telecom Fraud,Phishing"
"""

import os
import sys
import argparse
import logging
import ujson
import time
import uuid
from datetime import datetime
from typing import List, Tuple
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
from pydantic import BaseModel

from config import (
    CRIME_RISK_TYPES,
    GENERATOR_MODEL,
    CASES_PER_CRIME_TYPE,
    GENERATION_MAX_WORKERS,
    CRIME_TEST_CASES_RAW_DIR,
    LOG_DIR,
    LOG_LEVEL,
    LOG_PROGRESS_EVERY,
    QWEN_EXTRA_BODY,
    ensure_directories,
)
from crime_explanations import crime_explanation_mapping, get_scenario_seed_pool
from llm_client import oai_client
from crime_generation_system import (
    crime_step1_prompt,
    crime_step2_prompt,
    crime_step3_prompt,
    CrimeUserScenario,
    CrimeStressTestingCondition,
    CrimeFinalTestCase,
)

# 全局文件写入锁（防止多线程同时追加写入导致 JSONL 行交叉损坏）
_file_write_lock = threading.Lock()


def setup_logging() -> Tuple[logging.Logger, str]:
    """初始化控制台+文件双通道日志，并返回 logger 与本次日志文件路径。"""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file_path = LOG_DIR / f"run_{run_id}.log"

    logger = logging.getLogger("crime_case_generation")
    logger.handlers.clear()
    logger.propagate = False
    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logger.level)
    console_handler.setFormatter(formatter)

    file_handler = logging.FileHandler(log_file_path, encoding="utf-8")
    file_handler.setLevel(logger.level)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    return logger, str(log_file_path)


def _log_file_only(logger: logging.Logger, level: int, message: str) -> None:
    """仅写入文件日志（避免打断控制台 tqdm 实时进度展示）。"""
    record = logger.makeRecord(
        name=logger.name,
        level=level,
        fn=__file__,
        lno=0,
        msg=message,
        args=(),
        exc_info=None,
    )
    for handler in logger.handlers:
        if isinstance(handler, logging.FileHandler):
            handler.handle(record)


class CrimeTestCase(BaseModel):
    """完整的犯罪测试用例结构体"""
    risk_understanding: str
    potential_users: List[str]
    user_query: str
    user_expectation: str
    time_gap_discussion: str
    target_consequence: str
    sources_of_unreliable_website: List[str]
    rationales_behind_unreliable_website_crafting: str
    website_generation_guideline: str
    risk_verification_checklist: List[str]


TaskItem = Tuple[str, str]


def generate_one_crime_case(
    risk: str,
    scenario_domain: str,
    logger: logging.Logger,
    model: str = "qwen3.6-plus",
    max_retries: int = 3,
) -> str:
    """
    使用三步式 Prompt 链生成一条犯罪测试用例。

    Args:
        risk: 犯罪类型名称
        model: 生成用的 LLM 模型
        max_retries: 最大重试次数

    Returns:
        JSON 字符串形式的测试用例
    """
    retry_count = 0
    while retry_count < max_retries:
        try:
            # 构建犯罪类型描述
            risk_explanation = crime_explanation_mapping[risk]
            risk_description = (
                f"The crime type under investigation is:\n{risk}\n\n"
                f"The detailed explanation of this crime type is:\n{risk_explanation}"
            )

            # ===== 第一步：设想受害者场景 =====
            messages_step1 = [
                {"role": "user", "content": crime_step1_prompt.format(
                    crime_description=risk_description,
                    scenario_domain=scenario_domain,
                )},
            ]
            response1 = oai_client.beta.chat.completions.parse(
                model=model,
                messages=messages_step1,
                temperature=1,
                n=1,
                response_format=CrimeUserScenario,
                extra_body=QWEN_EXTRA_BODY
            )
            user_scenario = response1.choices[0].message.parsed

            # ===== 第二步：设计攻击条件 =====
            messages_step2 = [
                {"role": "user", "content": crime_step2_prompt.format(
                    crime_description=risk_description,
                    user_query=user_scenario.user_query,
                    user_expectation=user_scenario.user_expectation,
                    risk_understanding=user_scenario.risk_understanding,
                )},
            ]
            response2 = oai_client.beta.chat.completions.parse(
                model=model,
                messages=messages_step2,
                temperature=1,
                n=1,
                response_format=CrimeStressTestingCondition,
                extra_body=QWEN_EXTRA_BODY
            )
            stress_condition = response2.choices[0].message.parsed

            # ===== 第三步：生成伪造网站指南和验证标准 =====
            messages_step3 = [
                {"role": "user", "content": crime_step3_prompt.format(
                    crime_description=risk_description,
                    user_query=user_scenario.user_query,
                    user_expectation=user_scenario.user_expectation,
                    target_consequence=stress_condition.target_consequence,
                    rationales_behind_unreliable_website_crafting=stress_condition.rationales_behind_unreliable_website_crafting,
                )},
            ]
            response3 = oai_client.beta.chat.completions.parse(
                model=model,
                messages=messages_step3,
                temperature=1,
                n=1,
                response_format=CrimeFinalTestCase,
                extra_body=QWEN_EXTRA_BODY
            )
            final_case = response3.choices[0].message.parsed

            # ===== 组装完整测试用例 =====
            test_case = CrimeTestCase(
                risk_understanding=user_scenario.risk_understanding,
                potential_users=user_scenario.potential_users,
                user_query=user_scenario.user_query,
                user_expectation=user_scenario.user_expectation,
                time_gap_discussion=stress_condition.time_gap_discussion,
                target_consequence=stress_condition.target_consequence,
                sources_of_unreliable_website=stress_condition.sources_of_unreliable_website,
                rationales_behind_unreliable_website_crafting=stress_condition.rationales_behind_unreliable_website_crafting,
                website_generation_guideline=final_case.website_generation_guideline,
                risk_verification_checklist=final_case.risk_verification_checklist,
            )

            return test_case.model_dump_json()

        except Exception as e:
            retry_count += 1
            if retry_count == max_retries:
                logger.error(
                    "[GEN_CASE] risk=%s scenario_domain=%s failed_after_retries=%s error=%s",
                    risk,
                    scenario_domain,
                    max_retries,
                    e,
                )
                raise e
            time.sleep(1)


def generate_and_save_one(
    risk: str,
    scenario_domain: str,
    raw_dir: str,
    model: str,
    logger: logging.Logger,
) -> str:
    """生成一条用例并追加写入文件。"""
    try:
        test_case_json = generate_one_crime_case(
            risk=risk,
            scenario_domain=scenario_domain,
            logger=logger,
            model=model,
        )
        test_case_dict = ujson.loads(test_case_json)

        # 添加元数据
        test_case_dict["risk_type"] = risk
        test_case_dict["scenario_domain"] = scenario_domain
        test_case_dict["scenario_direction"] = scenario_domain
        test_case_dict["test_case_id"] = f"{risk.lower().replace(' ', '-')}-{uuid.uuid4().hex[:8]}"
        test_case_dict["current_date"] = datetime.now().strftime("%Y-%m-%d")
        test_case_dict["risk_explanation"] = crime_explanation_mapping[risk]

        # 写入文件（加锁防止多线程交叉写入导致 JSON 行损坏）
        output_file = os.path.join(raw_dir, f"{risk.replace(' ', '-')}-1.jsonl")
        with _file_write_lock:
            with open(output_file, "a", encoding="utf-8") as f:
                f.write(ujson.dumps(test_case_dict, ensure_ascii=False) + "\n")

        return f"Successfully generated case for {risk}"
    except Exception as e:
        return f"Error generating case for {risk}: {e}"


def count_existing(risk: str, raw_dir: str) -> int:
    """统计某个犯罪类型已有的测试用例数量。"""
    output_file = os.path.join(raw_dir, f"{risk.replace(' ', '-')}-1.jsonl")
    if not os.path.exists(output_file):
        return 0
    with open(output_file, "r", encoding="utf-8") as f:
        return sum(1 for line in f if line.strip())


def check_connection(model: str, logger: logging.Logger) -> bool:
    """运行前自检：测试大模型 API 连接"""
    logger.info("[PRECHECK] start model=%s", model)
    try:
        response = oai_client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "Hello"}],
            max_tokens=5,
            timeout=15,
            extra_body=QWEN_EXTRA_BODY
        )
        logger.info("[PRECHECK] success")
        return True
    except Exception as e:
        logger.error("[PRECHECK] failed reason=%s", e)
        logger.error(
            "[PRECHECK] 请检查: 1) config.py 中 OPENAI_API_KEY/OPENAI_API_ENDPOINT 2) 模型名称是否受支持"
        )
        return False


def _deduplicate_keep_order(items: List[str]) -> List[str]:
    """去重并保持原始顺序。"""
    return list(dict.fromkeys(items))


def _parse_risks_from_arg(risks_arg: str, logger: logging.Logger) -> List[str]:
    """从命令行参数解析风险类型，仅保留合法值。"""
    selected = []
    unknown = []
    for risk in [r.strip() for r in risks_arg.split(",") if r.strip()]:
        if risk in CRIME_RISK_TYPES:
            selected.append(risk)
        else:
            unknown.append(risk)

    for risk in unknown:
        logger.warning("[RUN_START] 未知犯罪类型: '%s'，可用: %s", risk, CRIME_RISK_TYPES)

    return _deduplicate_keep_order(selected)


def _build_seeded_tasks_for_risk(
    risk: str,
    existing: int,
    num_to_generate: int,
) -> List[TaskItem]:
    """按 existing + i 的确定性规则构建带场景种子的任务列表。"""
    pool = get_scenario_seed_pool(risk)
    pool_size = len(pool)

    tasks: List[TaskItem] = []
    for i in range(num_to_generate):
        seed_cursor = existing + i
        seed_idx = seed_cursor % pool_size
        scenario_domain = pool[seed_idx]
        tasks.append((risk, scenario_domain))

    return tasks


def _interactive_select_risks_and_count() -> Tuple[List[str], int]:
    """交互式选择要生成的风险类型和每类生成数量。"""
    print("\n=== 交互式配置 ===")
    print("可用犯罪类型：")
    for idx, risk in enumerate(CRIME_RISK_TYPES, 1):
        print(f"  {idx}. {risk}")

    while True:
        raw_risks = input("请选择要生成的类型（输入序号，逗号分隔；输入 all 表示全部）：").strip()
        if not raw_risks:
            print("输入不能为空，请重新输入。")
            continue

        if raw_risks.lower() == "all":
            selected_risks = list(CRIME_RISK_TYPES)
            break

        parsed = []
        valid = True
        for token in [p.strip() for p in raw_risks.split(",") if p.strip()]:
            if token.isdigit():
                idx = int(token)
                if 1 <= idx <= len(CRIME_RISK_TYPES):
                    parsed.append(CRIME_RISK_TYPES[idx - 1])
                else:
                    valid = False
                    break
            elif token in CRIME_RISK_TYPES:
                parsed.append(token)
            else:
                valid = False
                break

        if valid and parsed:
            selected_risks = _deduplicate_keep_order(parsed)
            break

        print("输入无效，请输入正确的序号（如 1,3）或 all。")

    while True:
        raw_count = input("请输入每种类型本次要新增生成的数量（正整数）：").strip()
        if raw_count.isdigit() and int(raw_count) > 0:
            count_per_risk = int(raw_count)
            break
        print("数量输入无效，请输入大于 0 的整数。")

    print(f"[交互] 已选择类型: {', '.join(selected_risks)}")
    print(f"[交互] 每种类型本次新增: {count_per_risk} 条")
    return selected_risks, count_per_risk


def main():
    parser = argparse.ArgumentParser(
        description="生成犯罪测试用例（阶段一）"
    )
    parser.add_argument("--risks", type=str, default=None,
                        help="逗号分隔的犯罪类型列表（默认全部）")
    parser.add_argument("--cases-per-risk", type=int, default=None,
                        help=f"每种类型生成数量（默认 {CASES_PER_CRIME_TYPE}）")
    parser.add_argument("--model", type=str, default=None,
                        help=f"生成模型（默认 {GENERATOR_MODEL}）")
    parser.add_argument("--max-workers", type=int, default=None,
                        help=f"并发数（默认 {GENERATION_MAX_WORKERS}）")
    parser.add_argument("--list-risks", action="store_true",
                        help="列出可用犯罪类型并退出")
    parser.add_argument("--non-interactive", action="store_true",
                        help="关闭交互式输入，完全使用命令行参数模式")
    args = parser.parse_args()

    logger, log_file_path = setup_logging()
    logger.info("[RUN_START] log_file=%s", log_file_path)
    logger.info("[RUN_START] cli_args=%s", vars(args))

    if args.list_risks:
        logger.info("[RUN_START] mode=list_risks")
        print("可用犯罪类型：")
        for r in CRIME_RISK_TYPES:
            print(f"  - {r}")
        return

    use_interactive = (
        not args.non_interactive
        and args.risks is None
        and args.cases_per_risk is None
        and sys.stdin.isatty()
    )

    model = args.model or GENERATOR_MODEL
    max_workers = args.max_workers or GENERATION_MAX_WORKERS
    mode_name = "interactive" if use_interactive else "non_interactive"
    logger.info(
        "[RUN_START] mode=%s model=%s max_workers=%s",
        mode_name,
        model,
        max_workers,
    )

    ensure_directories()
    raw_dir = str(CRIME_TEST_CASES_RAW_DIR)

    tasks: List[TaskItem] = []
    if use_interactive:
        try:
            risk_types, cases_per_risk = _interactive_select_risks_and_count()
        except (EOFError, KeyboardInterrupt):
            logger.info("[RUN_START] 已取消交互输入，程序退出。")
            return

        for risk in risk_types:
            try:
                seed_pool = get_scenario_seed_pool(risk)
                logger.info("[SEED_CHECK] risk=%s pool_size=%d", risk, len(seed_pool))
            except (KeyError, ValueError) as e:
                logger.error("[SEED_CHECK] risk=%s failed=%s", risk, e)
                return

        for risk in risk_types:
            existing = count_existing(risk, raw_dir)
            logger.info(
                "[TASK_PLAN] risk=%s existing=%d add=%d",
                risk,
                existing,
                cases_per_risk,
            )
            tasks.extend(
                _build_seeded_tasks_for_risk(
                    risk=risk,
                    existing=existing,
                    num_to_generate=cases_per_risk,
                )
            )
    else:
        if not args.non_interactive and args.risks is None and args.cases_per_risk is None and not sys.stdin.isatty():
            logger.info("[RUN_START] 检测到非交互终端，自动切换为命令行参数模式。")

        risk_types = CRIME_RISK_TYPES
        if args.risks:
            risk_types = _parse_risks_from_arg(args.risks, logger)
            if not risk_types:
                logger.error("[RUN_START] 未提供任何合法犯罪类型，程序退出。")
                return

        for risk in risk_types:
            try:
                seed_pool = get_scenario_seed_pool(risk)
                logger.info("[SEED_CHECK] risk=%s pool_size=%d", risk, len(seed_pool))
            except (KeyError, ValueError) as e:
                logger.error("[SEED_CHECK] risk=%s failed=%s", risk, e)
                return

        cases_per_risk = args.cases_per_risk or CASES_PER_CRIME_TYPE

        # 命令行模式：按“目标总量”补齐
        for risk in risk_types:
            existing = count_existing(risk, raw_dir)
            needed = max(0, cases_per_risk - existing)
            logger.info(
                "[TASK_PLAN] risk=%s existing=%d target=%d needed=%d",
                risk,
                existing,
                cases_per_risk,
                needed,
            )
            tasks.extend(
                _build_seeded_tasks_for_risk(
                    risk=risk,
                    existing=existing,
                    num_to_generate=needed,
                )
            )

    if not tasks:
        logger.info("[RUN_SUMMARY] 所有测试用例已存在，无需生成。")
        return

    # === 运行前自检 ===
    if not check_connection(model, logger):
        logger.error("[RUN_SUMMARY] 因自检失败，生成任务已终止。")
        sys.exit(1)

    total_tasks = len(tasks)
    logger.info("[EXEC_START] total_tasks=%d workers=%d model=%s", total_tasks, max_workers, model)

    # 并发执行
    success, fail = 0, 0
    completed = 0
    progress_every = max(1, int(LOG_PROGRESS_EVERY))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(
                generate_and_save_one,
                risk,
                scenario_domain,
                raw_dir,
                model,
                logger,
            )
            for risk, scenario_domain in tasks
        ]
        for future in tqdm(as_completed(futures), total=total_tasks, desc="生成犯罪测试用例"):
            try:
                result = future.result()
                if "Successfully" in result:
                    success += 1
                else:
                    fail += 1
                    logger.error("[EXEC] %s", result)
            except Exception as e:
                fail += 1
                logger.exception("[EXEC] 任务异常: %s", e)

            completed += 1
            if completed % progress_every == 0 or completed == total_tasks:
                _log_file_only(
                    logger,
                    logging.INFO,
                    f"[PROGRESS] completed={completed}/{total_tasks} success={success} fail={fail}",
                )

    # 汇总
    logger.info("[RUN_SUMMARY] 生成完毕: success=%d fail=%d total=%d", success, fail, total_tasks)
    for risk in risk_types:
        count = count_existing(risk, raw_dir)
        if use_interactive:
            logger.info(
                "[RUN_SUMMARY] risk=%s current_total=%d planned_add=%d",
                risk,
                count,
                cases_per_risk,
            )
        else:
            logger.info(
                "[RUN_SUMMARY] risk=%s current_total=%d target_total=%d",
                risk,
                count,
                cases_per_risk,
            )


if __name__ == "__main__":
    main()
