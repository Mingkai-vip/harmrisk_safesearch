﻿from openai import OpenAI

from config import OPENAI_API_ENDPOINT, OPENAI_API_KEY

oai_client = OpenAI(
    api_key=OPENAI_API_KEY,
    base_url=OPENAI_API_ENDPOINT,
)
