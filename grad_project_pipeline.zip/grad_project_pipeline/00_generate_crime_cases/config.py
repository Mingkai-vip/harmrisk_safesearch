﻿#!/usr/bin/env python3
"""
阶段一（犯罪测试用例生成）独立配置。
"""

from pathlib import Path

# 犯罪风险类型列表
# 这里保留英文值，便于后续程序直接使用
# 每个英文标签后面的中文注释用于帮助理解具体含义
CRIME_RISK_TYPES = [
    "Telecom Fraud",        # 电信诈骗
    "Phishing",             # 网络钓鱼
    "Pyramid Scheme",       # 传销骗局
    "Dark Web Trading",     # 暗网交易
    "Fabricated Crisis",    # 公共安全危机事件
]

# -----------------------------
# 模型与运行参数配置
# -----------------------------

# 用于生成测试用例的模型名称
# 当前使用阿里通义千问兼容接口中的 qwen3.6-plus
GENERATOR_MODEL = "qwen3.6-plus"

# 生成任务的最大并发工作线程数
# 数值越大，生成速度通常越快，但也会增加接口并发压力
GENERATION_MAX_WORKERS = 8

# 每一种犯罪类型默认生成的测试用例数量
CASES_PER_CRIME_TYPE = 60

# -----------------------------
# API 配置
# -----------------------------
# 按当前项目要求，将 API 信息直接写在配置文件中
# OPENAI_API_ENDPOINT 使用的是阿里云 DashScope 提供的 OpenAI 兼容接口地址
OPENAI_API_KEY = "sk-9e5a9b1755de4b7ea7a1653cab64b919"
OPENAI_API_ENDPOINT = "https://dashscope.aliyuncs.com/compatible-mode/v1"

# 阿里 Qwen 模型额外参数配置
# enable_thinking=False 表示关闭深度思考模式
# 这样可以减少额外推理过程输出，使生成更直接
QWEN_EXTRA_BODY = {"enable_thinking": False}

# -----------------------------
# 输出路径配置
# -----------------------------
# 当前模块目录
MODULE_ROOT = Path(__file__).resolve().parent

# 共享数据总目录（00/01 共用）
PIPELINE_DATA_DIR = MODULE_ROOT.parent / "data"

# 阶段一生成的原始犯罪测试用例输出目录
CRIME_TEST_CASES_RAW_DIR = PIPELINE_DATA_DIR / "01_raw_cases"

# 日志输出目录
# 用于保存运行日志，便于调试和排查问题
LOG_DIR = MODULE_ROOT / "logs"

# -----------------------------
# 日志配置
# -----------------------------

# 日志级别
# 常见可选值有 DEBUG、INFO、WARNING、ERROR
LOG_LEVEL = "INFO"

# 每完成多少条任务记录一次进度日志
# 例如这里为 10，表示每完成 10 条任务写一次进度信息
LOG_PROGRESS_EVERY = 10


def ensure_directories() -> None:
    """确保阶段一输出目录和日志目录存在。"""
    # 如果原始测试用例目录不存在，则递归创建
    # parents=True 表示父目录不存在时一并创建
    # exist_ok=True 表示目录已存在时不报错
    CRIME_TEST_CASES_RAW_DIR.mkdir(parents=True, exist_ok=True)

    # 如果日志目录不存在，也自动创建
    LOG_DIR.mkdir(parents=True, exist_ok=True)


# 模块在被导入时自动创建目录
# 这样可以避免后续写文件或写日志时因为目录不存在而报错
ensure_directories()
