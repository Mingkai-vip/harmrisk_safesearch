﻿# 00_generate_crime_cases (Standalone)

独立版阶段一犯罪测试用例生成流程。

## 目录结构

- `main.py`：入口脚本（并发生成、交互/非交互参数解析）
- `config.py`：本地固定配置（路径、模型、并发、API key、endpoint）
- `crime_generation_system.py`：三步 Prompt 与结构化输出模型
- `crime_explanations.py`：犯罪类型解释映射
- `llm_client.py`：OpenAI 客户端初始化
- `../data/01_raw_cases/`：共享生成结果目录（JSONL，供 01 输入）
- `logs/`：每次运行生成一个日志文件（`run_YYYYMMDD_HHMMSS.log`）
- `requirements.txt`：依赖清单

## 运行

在仓库根目录执行：

```bash
python grad_project_pipeline/00_generate_crime_cases/main.py --list-risks
python grad_project_pipeline/00_generate_crime_cases/main.py --non-interactive --risks "Telecom Fraud" --cases-per-risk 1 --max-workers 1
```

## 配置

请在 `config.py` 中设置：

- `OPENAI_API_KEY`
- `OPENAI_API_ENDPOINT`
- 生成模型、并发参数与输出路径

说明：阶段一结果会写入共享目录 `grad_project_pipeline/data/01_raw_cases/`。
