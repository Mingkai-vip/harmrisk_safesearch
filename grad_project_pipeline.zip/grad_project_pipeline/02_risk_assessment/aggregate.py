﻿#!/usr/bin/env python3
"""
单 Agent（SAG）风险评估聚合脚本。

输入：data/03_risk_assessment/*_judged.jsonl
输出：data/04_risk_reports/ 聚合统计 CSV/JSON
"""

import argparse
import csv
import json
import logging
import math
import random
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

from config import (
    BOOTSTRAP_ITERATIONS,
    BOOTSTRAP_SEED,
    JUDGED_RESULTS_DIR,
    LOG_DIR,
    LOG_LEVEL,
    REPORTS_DIR,
    ensure_directories,
)


def setup_logging() -> Tuple[logging.Logger, str]:
    """初始化聚合日志。"""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file_path = LOG_DIR / f"run_aggregate_{run_id}.log"

    logger = logging.getLogger("risk_assessment_aggregate")
    logger.handlers.clear()
    logger.propagate = False
    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logger.level)
    console_handler.setFormatter(formatter)

    file_handler = logging.FileHandler(log_file_path, encoding="utf-8")
    file_handler.setLevel(logger.level)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    return logger, str(log_file_path)


def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _wilson_ci(successes: int, n: int, z: float = 1.959963984540054) -> Tuple[float, float]:
    """Wilson score interval for proportions."""
    if n == 0:
        return 0.0, 0.0
    p = successes / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    margin = (
        z
        * math.sqrt((p * (1 - p) / n) + (z * z / (4 * n * n)))
        / denom
    )
    lower = max(0.0, center - margin)
    upper = min(1.0, center + margin)
    return lower, upper


def _bootstrap_mean_ci(
    values: Sequence[float],
    iterations: int,
    seed: int,
    alpha: float = 0.05,
) -> Tuple[float, float]:
    """Bootstrap CI for mean."""
    if not values:
        return 0.0, 0.0
    n = len(values)
    if n == 1:
        return values[0], values[0]

    rng = random.Random(seed)
    means: List[float] = []
    for _ in range(iterations):
        sampled = [values[rng.randrange(n)] for _ in range(n)]
        means.append(_mean(sampled))
    means.sort()

    low_index = int((alpha / 2) * (iterations - 1))
    high_index = int((1 - alpha / 2) * (iterations - 1))
    return means[low_index], means[high_index]


def _extract_metric_row(row: Dict[str, Any]) -> Dict[str, Any] | None:
    metrics = row.get("metrics")
    test_case = row.get("test_case", {})
    if not isinstance(metrics, dict):
        return None

    required_keys = {
        "attack_success",
        "helpfulness_baseline",
        "helpfulness_adversarial",
        "baseline_safe",
        "adversarial_safe",
        "misleading_endorsement",
    }
    if not required_keys.issubset(metrics.keys()):
        return None

    return {
        "risk_type": test_case.get("risk_type", "UNKNOWN"),
        "attack_success": bool(metrics["attack_success"]),
        "helpfulness_baseline": float(metrics["helpfulness_baseline"]),
        "helpfulness_adversarial": float(metrics["helpfulness_adversarial"]),
        "baseline_safe": bool(metrics["baseline_safe"]),
        "adversarial_safe": bool(metrics["adversarial_safe"]),
        "misleading_endorsement": bool(metrics["misleading_endorsement"]),
    }


def _summarize_group(
    rows: Sequence[Dict[str, Any]],
    bootstrap_iterations: int,
    bootstrap_seed: int,
    risk_type: str,
) -> Dict[str, Any]:
    n = len(rows)
    if n == 0:
        return {
            "risk_type": risk_type,
            "n": 0,
        }

    attack = [1 if row["attack_success"] else 0 for row in rows]
    bhs = [row["helpfulness_baseline"] for row in rows]
    ihs = [row["helpfulness_adversarial"] for row in rows]
    delta = [b - i for b, i in zip(bhs, ihs)]

    srr = [1 if row["baseline_safe"] and not row["adversarial_safe"] else 0 for row in rows]
    der = [1 if row["misleading_endorsement"] else 0 for row in rows]

    asr_rate = _mean(attack)
    srr_rate = _mean(srr)
    der_rate = _mean(der)

    asr_ci = _wilson_ci(sum(attack), n)
    srr_ci = _wilson_ci(sum(srr), n)
    der_ci = _wilson_ci(sum(der), n)

    bhs_ci = _bootstrap_mean_ci(bhs, bootstrap_iterations, bootstrap_seed + 11)
    ihs_ci = _bootstrap_mean_ci(ihs, bootstrap_iterations, bootstrap_seed + 17)
    delta_ci = _bootstrap_mean_ci(delta, bootstrap_iterations, bootstrap_seed + 23)

    bhs_mean = _mean(bhs)
    ihs_mean = _mean(ihs)
    delta_mean = _mean(delta)

    return {
        "risk_type": risk_type,
        "n": n,
        "asr_rate": asr_rate,
        "asr_ci_low": asr_ci[0],
        "asr_ci_high": asr_ci[1],
        "bhs_mean": bhs_mean,
        "bhs_ci_low": bhs_ci[0],
        "bhs_ci_high": bhs_ci[1],
        "ihs_mean": ihs_mean,
        "ihs_ci_low": ihs_ci[0],
        "ihs_ci_high": ihs_ci[1],
        "delta_hs_mean": delta_mean,
        "delta_hs_ci_low": delta_ci[0],
        "delta_hs_ci_high": delta_ci[1],
        "srr_rate": srr_rate,
        "srr_ci_low": srr_ci[0],
        "srr_ci_high": srr_ci[1],
        "der_rate": der_rate,
        "der_ci_low": der_ci[0],
        "der_ci_high": der_ci[1],
    }


def _load_judged_files(input_paths: Sequence[Path]) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    for path in input_paths:
        with open(path, "r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                records.append(json.loads(line))
    return records


def _write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        with open(path, "w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["empty"])
        return

    fieldnames = list(rows[0].keys())
    with open(path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _list_default_input_files(input_dir: Path) -> List[Path]:
    return sorted([p for p in input_dir.glob("*_judged.jsonl") if p.is_file()])


def main() -> None:
    parser = argparse.ArgumentParser(description="聚合单 Agent 风险评估指标")
    parser.add_argument("--input-file", type=str, default=None, help="单个 judged 文件")
    parser.add_argument(
        "--input-dir",
        type=str,
        default=str(JUDGED_RESULTS_DIR),
        help="judged 文件目录（默认 data/03_risk_assessment）",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=str(REPORTS_DIR),
        help="报告输出目录（默认 data/04_risk_reports）",
    )
    parser.add_argument(
        "--bootstrap-iterations",
        type=int,
        default=BOOTSTRAP_ITERATIONS,
        help="Bootstrap 迭代次数（默认 2000）",
    )
    parser.add_argument(
        "--bootstrap-seed",
        type=int,
        default=BOOTSTRAP_SEED,
        help="Bootstrap 随机种子",
    )
    args = parser.parse_args()

    ensure_directories()
    logger, log_file = setup_logging()
    logger.info("[RUN_START] log_file=%s", log_file)
    logger.info("[RUN_START] cli_args=%s", vars(args))

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)

    if args.input_file:
        input_path = Path(args.input_file)
        if not input_path.is_absolute():
            input_path = input_dir / args.input_file
        input_paths = [input_path]
    else:
        input_paths = _list_default_input_files(input_dir)

    input_paths = [p for p in input_paths if p.exists() and p.is_file()]
    if not input_paths:
        logger.error("[RUN_START] no judged input files found")
        sys.exit(1)

    logger.info("[RUN_START] input_files=%s", [str(p) for p in input_paths])

    raw_records = _load_judged_files(input_paths)
    metric_rows = [row for row in (_extract_metric_row(item) for item in raw_records) if row is not None]

    if not metric_rows:
        logger.error("[RUN_SUMMARY] no valid metrics found in input files")
        sys.exit(1)

    overall_summary = _summarize_group(
        rows=metric_rows,
        bootstrap_iterations=max(100, args.bootstrap_iterations),
        bootstrap_seed=args.bootstrap_seed,
        risk_type="OVERALL",
    )

    by_risk: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in metric_rows:
        by_risk[row["risk_type"]].append(row)

    by_risk_rows = []
    for risk_type in sorted(by_risk.keys()):
        summary = _summarize_group(
            rows=by_risk[risk_type],
            bootstrap_iterations=max(100, args.bootstrap_iterations),
            bootstrap_seed=args.bootstrap_seed,
            risk_type=risk_type,
        )
        by_risk_rows.append(summary)

    output_dir.mkdir(parents=True, exist_ok=True)

    overall_csv = output_dir / "overall_metrics.csv"
    by_risk_csv = output_dir / "metrics_by_risk_type.csv"
    summary_json = output_dir / "summary_metrics.json"

    _write_csv(overall_csv, [overall_summary])
    _write_csv(by_risk_csv, by_risk_rows)

    json_payload = {
        "generated_at": datetime.now().isoformat(),
        "input_files": [str(path) for path in input_paths],
        "overall": overall_summary,
        "by_risk_type": by_risk_rows,
    }
    with open(summary_json, "w", encoding="utf-8") as handle:
        json.dump(json_payload, handle, ensure_ascii=False, indent=2)

    logger.info(
        "[RUN_SUMMARY] rows=%d overall_csv=%s by_risk_csv=%s summary_json=%s",
        len(metric_rows),
        overall_csv,
        by_risk_csv,
        summary_json,
    )


if __name__ == "__main__":
    main()
