﻿#!/usr/bin/env python3
"""
阶段二后评估（单 Agent 风险评估）配置。
"""

from pathlib import Path

# -----------------------------
# 裁判模型配置
# -----------------------------

# 用于风险评估打分的裁判模型名称
JUDGE_MODEL = "qwen3.6-plus"

# 裁判模型温度参数
# 设为 0.0 表示输出更稳定，便于评估结果保持一致性
JUDGE_TEMPERATURE = 0.0

# 并发执行的最大线程数
MAX_WORKERS = 8

# 单个任务失败后的最大重试次数
MAX_RETRIES = 3

# 阿里 DashScope 提供的 OpenAI 兼容接口地址
OPENAI_API_ENDPOINT = "https://dashscope.aliyuncs.com/compatible-mode/v1"

# API Key
# 当前按配置文件直写方式保存
OPENAI_API_KEY = "sk-9e5a9b1755de4b7ea7a1653cab64b919"

# Qwen 模型额外参数
# enable_thinking=False 表示关闭深度思考模式
QWEN_EXTRA_BODY = {"enable_thinking": False}

# -----------------------------
# 路径配置
# -----------------------------

# 当前配置文件所在目录
MODULE_ROOT = Path(__file__).resolve().parent

# 流水线根目录
# 这里取当前模块目录的上一级目录
PIPELINE_ROOT = MODULE_ROOT.parent

# 数据总目录
DATA_DIR = PIPELINE_ROOT / "data"

# 阶段二 Agent 输出结果目录
AGENT_RESULTS_DIR = DATA_DIR / "02_agent_results"

# 阶段三裁判模型评估后的结果目录
JUDGED_RESULTS_DIR = DATA_DIR / "03_risk_assessment"

# 阶段四统计报告输出目录
REPORTS_DIR = DATA_DIR / "04_risk_reports"

# 日志目录
LOG_DIR = MODULE_ROOT / "logs"

# -----------------------------
# 统计配置
# -----------------------------

# Bootstrap 重采样次数
# 数值越大，统计结果通常越稳定，但耗时也会增加
BOOTSTRAP_ITERATIONS = 2000

# Bootstrap 随机种子
# 固定随机种子有助于保证实验可复现
BOOTSTRAP_SEED = 42

# 人工抽样复核比例
# 这里设置为 0.10，表示抽取 10% 的样本进行人工复核
MANUAL_REVIEW_SAMPLE_RATE = 0.10

# 日志级别
# 常见取值包括 DEBUG、INFO、WARNING、ERROR
LOG_LEVEL = "INFO"


def ensure_directories() -> None:
    """确保评估阶段所需目录存在。"""
    # 裁判评估结果目录，不存在时自动创建
    JUDGED_RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    # 统计报告目录，不存在时自动创建
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    # 日志目录，不存在时自动创建
    LOG_DIR.mkdir(parents=True, exist_ok=True)


# 模块导入时自动创建目录
# 这样可以避免后续写评估结果、报告或日志时因目录不存在而报错
ensure_directories()