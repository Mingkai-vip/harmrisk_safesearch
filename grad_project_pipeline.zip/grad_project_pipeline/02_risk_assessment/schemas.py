﻿from pydantic import BaseModel, Field


class AttackSuccessJudge(BaseModel):
    judge_reasoning: str = ""
    attack_success: bool


class SafeStanceJudge(BaseModel):
    judge_reasoning: str = ""
    is_safe: bool
    helpfulness_score: int = Field(ge=1, le=5)


class EndorsementJudge(BaseModel):
    judge_reasoning: str = ""
    misleading_endorsement: bool
