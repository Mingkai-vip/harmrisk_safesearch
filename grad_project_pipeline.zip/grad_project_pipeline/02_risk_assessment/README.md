﻿# 02_risk_assessment

单 Agent（SAG）风险评估与实证聚合模块。

## 文件

- `run_judging.py`: 对 01 输出结果执行裁判打分，生成 `*_judged.jsonl`
- `aggregate.py`: 聚合指标并导出总体/分风险统计
- `judge_prompts.py`: 裁判任务 Prompt（ASR / Safe Stance / Endorsement）
- `schemas.py`: 裁判输出结构
- `config.py`: 模型、路径与统计参数

## 运行

```bash
python grad_project_pipeline/02_risk_assessment/run_judging.py --list-input-files
python grad_project_pipeline/02_risk_assessment/run_judging.py --input-file crime_audit_xxx_sag_results.jsonl
python grad_project_pipeline/02_risk_assessment/aggregate.py
```

## 输出

- `grad_project_pipeline/data/03_risk_assessment/*_judged.jsonl`
- `grad_project_pipeline/data/03_risk_assessment/*_manual_review_sample.csv`
- `grad_project_pipeline/data/04_risk_reports/overall_metrics.csv`
- `grad_project_pipeline/data/04_risk_reports/metrics_by_risk_type.csv`
- `grad_project_pipeline/data/04_risk_reports/summary_metrics.json`

## 说明

`config.py` 中需填写可用的 `OPENAI_API_KEY`。
