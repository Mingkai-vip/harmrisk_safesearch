﻿#!/usr/bin/env python3
"""
单 Agent（SAG）风险评估打分脚本。

输入：01 阶段输出的 *_sag_results.jsonl（baseline/adversarial 结构）
输出：data/03_risk_assessment/*_judged.jsonl
"""

import argparse
import csv
import json
import logging
import random
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Tuple, Type

from pydantic import BaseModel
from tqdm import tqdm

from config import (
    AGENT_RESULTS_DIR,
    BOOTSTRAP_SEED,
    JUDGE_MODEL,
    JUDGE_TEMPERATURE,
    JUDGED_RESULTS_DIR,
    LOG_DIR,
    LOG_LEVEL,
    MANUAL_REVIEW_SAMPLE_RATE,
    MAX_RETRIES,
    MAX_WORKERS,
    OPENAI_API_KEY,
    QWEN_EXTRA_BODY,
    ensure_directories,
)
from judge_prompts import (
    ASR_SYSTEM_PROMPT,
    ASR_USER_TEMPLATE,
    ENDORSEMENT_SYSTEM_PROMPT,
    ENDORSEMENT_USER_TEMPLATE,
    SAFE_STANCE_SYSTEM_PROMPT,
    SAFE_STANCE_USER_TEMPLATE,
)
from llm_client import oai_client
from schemas import AttackSuccessJudge, EndorsementJudge, SafeStanceJudge


def setup_logging() -> Tuple[logging.Logger, str]:
    """初始化控制台 + 文件日志。"""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file_path = LOG_DIR / f"run_judging_{run_id}.log"

    logger = logging.getLogger("risk_assessment_judging")
    logger.handlers.clear()
    logger.propagate = False
    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logger.level)
    console_handler.setFormatter(formatter)

    file_handler = logging.FileHandler(log_file_path, encoding="utf-8")
    file_handler.setLevel(logger.level)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    return logger, str(log_file_path)


def _list_input_files() -> List[str]:
    """列出可用 SAG 结果文件。"""
    if not AGENT_RESULTS_DIR.exists():
        return []
    return sorted(
        [p.name for p in AGENT_RESULTS_DIR.glob("*_sag_results.jsonl") if p.is_file()]
    )


def _interactive_select_input_file(file_names: List[str]) -> str:
    """交互式选择输入文件。"""
    print("\n可用 SAG 结果文件：")
    for idx, name in enumerate(file_names, 1):
        print(f"  {idx}. {name}")

    while True:
        raw = input("请选择输入文件（输入序号或文件名）：").strip()
        if not raw:
            print("输入不能为空，请重新输入。")
            continue

        if raw.isdigit():
            index = int(raw)
            if 1 <= index <= len(file_names):
                return file_names[index - 1]
            print("序号超出范围，请重新输入。")
            continue

        if raw in file_names:
            return raw

        print("未找到该文件，请重新输入。")


def _safe_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    return str(value).strip()


def _format_checklist(checklist: Any) -> str:
    if isinstance(checklist, list):
        return "\n".join(str(item) for item in checklist)
    if isinstance(checklist, str):
        return checklist
    return ""


def _call_judge(
    system_prompt: str,
    user_prompt: str,
    response_model: Type[BaseModel],
    judge_model: str,
) -> BaseModel:
    """统一调用裁判 LLM，失败自动重试。"""
    last_error: Exception | None = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = oai_client.beta.chat.completions.parse(
                model=judge_model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=JUDGE_TEMPERATURE,
                response_format=response_model,
                extra_body=QWEN_EXTRA_BODY,
            )
            return response.choices[0].message.parsed
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            if attempt < MAX_RETRIES:
                time.sleep(1)

    raise RuntimeError(f"Judge call failed after {MAX_RETRIES} retries: {last_error}")


def judge_attack_success(
    test_case: Dict[str, Any],
    adversarial_response: str,
    judge_model: str,
) -> Dict[str, Any]:
    """判定 ASR：是否达成 target_consequence。"""
    if not adversarial_response:
        return {
            "attack_success": False,
            "judge_reasoning": "Missing adversarial response",
            "judge_model": judge_model,
        }

    prompt = ASR_USER_TEMPLATE.format(
        user_query=test_case.get("user_query", ""),
        user_expectation=test_case.get("user_expectation", ""),
        target_consequence=test_case.get("target_consequence", ""),
        risk_verification_checklist=_format_checklist(
            test_case.get("risk_verification_checklist", [])
        ),
        adversarial_response=adversarial_response,
    )

    judged = _call_judge(
        system_prompt=ASR_SYSTEM_PROMPT,
        user_prompt=prompt,
        response_model=AttackSuccessJudge,
        judge_model=judge_model,
    )
    return {
        "attack_success": judged.attack_success,
        "judge_reasoning": judged.judge_reasoning,
        "judge_model": judge_model,
    }


def judge_safe_stance(
    user_query: str,
    user_expectation: str,
    response_text: str,
    judge_model: str,
) -> Dict[str, Any]:
    """判定安全立场 + 有用性分（1-5）。"""
    if not response_text:
        return {
            "is_safe": False,
            "helpfulness_score": 1,
            "judge_reasoning": "Missing response",
            "judge_model": judge_model,
        }

    prompt = SAFE_STANCE_USER_TEMPLATE.format(
        user_query=user_query,
        user_expectation=user_expectation,
        response_text=response_text,
    )

    judged = _call_judge(
        system_prompt=SAFE_STANCE_SYSTEM_PROMPT,
        user_prompt=prompt,
        response_model=SafeStanceJudge,
        judge_model=judge_model,
    )

    return {
        "is_safe": judged.is_safe,
        "helpfulness_score": judged.helpfulness_score,
        "judge_reasoning": judged.judge_reasoning,
        "judge_model": judge_model,
    }


def judge_endorsement(
    test_case: Dict[str, Any],
    adversarial_response: str,
    judge_model: str,
) -> Dict[str, Any]:
    """判定是否存在误导性背书。"""
    if not adversarial_response:
        return {
            "misleading_endorsement": False,
            "judge_reasoning": "Missing adversarial response",
            "judge_model": judge_model,
        }

    prompt = ENDORSEMENT_USER_TEMPLATE.format(
        user_query=test_case.get("user_query", ""),
        target_consequence=test_case.get("target_consequence", ""),
        adversarial_response=adversarial_response,
    )

    judged = _call_judge(
        system_prompt=ENDORSEMENT_SYSTEM_PROMPT,
        user_prompt=prompt,
        response_model=EndorsementJudge,
        judge_model=judge_model,
    )

    return {
        "misleading_endorsement": judged.misleading_endorsement,
        "judge_reasoning": judged.judge_reasoning,
        "judge_model": judge_model,
    }


def process_one_record(record: Dict[str, Any], judge_model: str) -> Dict[str, Any]:
    """处理单条结果，产出新评估字段。"""
    test_case = record.get("test_case", {})

    baseline_response = _safe_text(record.get("baseline", {}).get("response"))
    adversarial_response = _safe_text(record.get("adversarial", {}).get("response"))

    attack = judge_attack_success(test_case, adversarial_response, judge_model)

    baseline_stance = judge_safe_stance(
        user_query=test_case.get("user_query", ""),
        user_expectation=test_case.get("user_expectation", ""),
        response_text=baseline_response,
        judge_model=judge_model,
    )

    adversarial_stance = judge_safe_stance(
        user_query=test_case.get("user_query", ""),
        user_expectation=test_case.get("user_expectation", ""),
        response_text=adversarial_response,
        judge_model=judge_model,
    )

    endorsement = judge_endorsement(test_case, adversarial_response, judge_model)

    output = dict(record)
    output["risk_assessment"] = {
        "attack_success_judge": attack,
        "baseline_safety_judge": baseline_stance,
        "adversarial_safety_judge": adversarial_stance,
        "endorsement_judge": endorsement,
        "judged_at": datetime.now().isoformat(),
    }

    output["metrics"] = {
        "attack_success": bool(attack["attack_success"]),
        "helpfulness_baseline": int(baseline_stance["helpfulness_score"]),
        "helpfulness_adversarial": int(adversarial_stance["helpfulness_score"]),
        "baseline_safe": bool(baseline_stance["is_safe"]),
        "adversarial_safe": bool(adversarial_stance["is_safe"]),
        "misleading_endorsement": bool(endorsement["misleading_endorsement"]),
    }

    return output


def load_jsonl(file_path: Path, limit: int | None = None) -> List[Dict[str, Any]]:
    """读取 jsonl 文件。"""
    records: List[Dict[str, Any]] = []
    with open(file_path, "r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            records.append(json.loads(line))
            if limit is not None and len(records) >= limit:
                break
    return records


def write_jsonl(file_path: Path, records: List[Dict[str, Any]]) -> None:
    """写出 jsonl 文件。"""
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as handle:
        for row in records:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def export_manual_review_sample(
    records: List[Dict[str, Any]],
    output_dir: Path,
    stem: str,
    sample_rate: float,
    sample_seed: int,
) -> Path | None:
    """导出人工复核抽样表（默认 10%）。"""
    if not records:
        return None

    rate = max(0.0, min(1.0, sample_rate))
    if rate == 0.0:
        return None

    sample_size = max(1, int(round(len(records) * rate)))
    sample_size = min(sample_size, len(records))

    rng = random.Random(sample_seed)
    picked_indices = sorted(rng.sample(range(len(records)), sample_size))

    sample_rows: List[Dict[str, Any]] = []
    for idx in picked_indices:
        row = records[idx]
        test_case = row.get("test_case", {})
        metrics = row.get("metrics", {})
        meta = row.get("meta", {})
        sample_rows.append(
            {
                "test_case_result_id": meta.get("test_case_result_id", ""),
                "risk_type": test_case.get("risk_type", ""),
                "user_query": test_case.get("user_query", ""),
                "target_consequence": test_case.get("target_consequence", ""),
                "baseline_response": row.get("baseline", {}).get("response", ""),
                "adversarial_response": row.get("adversarial", {}).get("response", ""),
                "model_attack_success": metrics.get("attack_success"),
                "model_baseline_safe": metrics.get("baseline_safe"),
                "model_adversarial_safe": metrics.get("adversarial_safe"),
                "model_misleading_endorsement": metrics.get("misleading_endorsement"),
                "human_attack_success": "",
                "human_baseline_safe": "",
                "human_adversarial_safe": "",
                "human_misleading_endorsement": "",
                "notes": "",
            }
        )

    output_path = output_dir / f"{stem}_manual_review_sample.csv"
    fieldnames = list(sample_rows[0].keys())

    with open(output_path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(sample_rows)

    return output_path


def main() -> None:
    parser = argparse.ArgumentParser(description="单 Agent 风险评估打分")
    parser.add_argument("--input-file", type=str, default=None, help="输入 SAG 结果文件名或绝对路径")
    parser.add_argument("--list-input-files", action="store_true", help="列出可用输入文件并退出")
    parser.add_argument("--output-file", type=str, default=None, help="输出 judged 文件路径")
    parser.add_argument("--judge-model", type=str, default=JUDGE_MODEL, help="裁判模型")
    parser.add_argument("--max-workers", type=int, default=MAX_WORKERS, help="并发数")
    parser.add_argument("--limit", type=int, default=None, help="只处理前 N 条（冒烟测试）")
    parser.add_argument(
        "--manual-sample-rate",
        type=float,
        default=MANUAL_REVIEW_SAMPLE_RATE,
        help="人工复核抽样比例，默认 0.10",
    )
    parser.add_argument(
        "--manual-sample-seed",
        type=int,
        default=BOOTSTRAP_SEED,
        help="人工复核抽样随机种子",
    )
    parser.add_argument("--skip-manual-sample", action="store_true", help="不导出人工复核抽样文件")
    args = parser.parse_args()

    ensure_directories()

    logger, log_file = setup_logging()
    logger.info("[RUN_START] log_file=%s", log_file)
    logger.info("[RUN_START] cli_args=%s", vars(args))

    available_files = _list_input_files()

    if args.list_input_files:
        print("可用 SAG 结果文件：")
        for file_name in available_files:
            print(f"  - {file_name}")
        return

    if args.input_file:
        selected_input = args.input_file.strip()
    else:
        if sys.stdin.isatty():
            if not available_files:
                logger.error("[RUN_START] no *_sag_results.jsonl under %s", AGENT_RESULTS_DIR)
                sys.exit(1)
            try:
                selected_input = _interactive_select_input_file(available_files)
            except (EOFError, KeyboardInterrupt):
                logger.error("[RUN_START] interactive selection cancelled")
                sys.exit(1)
        else:
            logger.error("[RUN_START] non-interactive mode requires --input-file")
            sys.exit(1)

    input_path = Path(selected_input)
    if not input_path.is_absolute():
        input_path = AGENT_RESULTS_DIR / selected_input

    if not input_path.exists() or not input_path.is_file():
        logger.error("[RUN_START] input file not found: %s", input_path)
        if available_files:
            logger.error("[RUN_START] available=%s", available_files)
        sys.exit(1)

    if input_path.suffix.lower() != ".jsonl":
        logger.error("[RUN_START] input file must be .jsonl: %s", input_path)
        sys.exit(1)

    if args.output_file:
        output_path = Path(args.output_file)
        if not output_path.is_absolute():
            output_path = JUDGED_RESULTS_DIR / args.output_file
    else:
        output_path = JUDGED_RESULTS_DIR / f"{input_path.stem}_judged.jsonl"

    records = load_jsonl(input_path, args.limit)
    if not records:
        logger.error("[RUN_START] no valid records loaded from %s", input_path)
        sys.exit(1)

    if not OPENAI_API_KEY.strip():
        logger.error(
            "[RUN_START] OPENAI_API_KEY is empty in grad_project_pipeline/02_risk_assessment/config.py"
        )
        sys.exit(1)

    logger.info(
        "[RUN_START] input=%s output=%s judge_model=%s total_records=%d max_workers=%d",
        input_path,
        output_path,
        args.judge_model,
        len(records),
        args.max_workers,
    )

    judged_results: List[Dict[str, Any]] = [None] * len(records)  # type: ignore[assignment]
    errors = 0

    logger.info("[EXEC_START] judging started")
    with ThreadPoolExecutor(max_workers=max(1, args.max_workers)) as executor:
        future_map = {
            executor.submit(process_one_record, record, args.judge_model): idx
            for idx, record in enumerate(records)
        }

        for future in tqdm(as_completed(future_map), total=len(future_map), desc="Risk Judging"):
            idx = future_map[future]
            try:
                judged_results[idx] = future.result()
            except Exception as exc:  # noqa: BLE001
                errors += 1
                logger.exception("[JUDGE_ERROR] idx=%d error=%s", idx, exc)
                fallback = dict(records[idx])
                fallback["risk_assessment"] = {
                    "error": str(exc),
                    "judged_at": datetime.now().isoformat(),
                }
                fallback["metrics"] = {
                    "attack_success": False,
                    "helpfulness_baseline": 1,
                    "helpfulness_adversarial": 1,
                    "baseline_safe": False,
                    "adversarial_safe": False,
                    "misleading_endorsement": False,
                }
                judged_results[idx] = fallback

    write_jsonl(output_path, judged_results)

    sample_path = None
    if not args.skip_manual_sample:
        sample_path = export_manual_review_sample(
            records=judged_results,
            output_dir=output_path.parent,
            stem=output_path.stem,
            sample_rate=args.manual_sample_rate,
            sample_seed=args.manual_sample_seed,
        )

    logger.info(
        "[RUN_SUMMARY] total=%d judge_errors=%d output=%s manual_sample=%s",
        len(judged_results),
        errors,
        output_path,
        sample_path,
    )


if __name__ == "__main__":
    main()
