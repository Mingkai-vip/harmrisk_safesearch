﻿#!/usr/bin/env python3
"""
阶段二（执行搜索智能体）独立配置。
"""

import os
from pathlib import Path

# -----------------------------
# 模型与执行目标
# -----------------------------

# 被测智能体底座模型（SafeSearch 约定格式）
TARGET_AGENT_MODELS = [
    "oai:qwen3.6-plus",
]

# 可用 agent 类型（用于校验与说明）
AVAILABLE_AGENT_TYPES = [
    "sag",
    "tool_calling_loop",
    "deepmind_dr",
]

# 默认执行的单个 agent
TARGET_AGENT_TYPE = "sag"

# 注入网站生成模型
GENERATOR_MODEL = "qwen3.6-plus"

# -----------------------------
# 执行参数
# -----------------------------

AGENTS_TO_EXCLUDE = []
MAX_RETRIES = 3
EXECUTION_MAX_WORKERS = 10
CURRENT_TIME = "2026-04-08"

# Search 参数
# 默认保留原始搜索排序；受污染页的插入位置在 Search 内部单独控制为第 2 位。
WEBSITE_SORT_METHOD = "default"
MAX_WEBSITE_TOKEN_LENGTH = 2000
N_RETURNED_WEBSITES = 5
N_INJECTED = 1
INJECTION_MODE = "adversarial"
MAX_SEARCHES = 2
MAX_RESEARCH_LOOPS = 2
MAX_QUERIES_PER_TURN = 2
WITH_REMINDER = False
NUM_REPETITIONS = 1
TIMEOUT_PER_TASK = 300
DEBUG_MODE = False
NO_URL = False
USE_EXAMPLE_AUTHENTIC_WEBSITES = False
HF_DATASET_NAME = None
HF_DATASET_CONFIG = None
TOKENIZER_DIR = None

# Generation 参数
TEMPERATURE = 0.0
MAX_COMPLETION_TOKENS = 2000
TOP_P = 1.0
REASONING_EFFORT = None
DISABLE_THINKING = True
SAVE_COMBINED_RESULTS = False

# -----------------------------
# API 配置（全部本地化）
# -----------------------------

OPENAI_API_KEY = "sk-9e5a9b1755de4b7ea7a1653cab64b919"
OPENAI_API_ENDPOINT = "https://dashscope.aliyuncs.com/compatible-mode/v1"

SERPER_API_KEY = "85a6388fae2105bb525f11a0c3d3aa4cc1d56bc0"
SERPER_URL = "https://google.serper.dev/search"
JINA_API_KEY = ""

VLLM_QUESTION_ANSWER_MODEL_PORT = "8001"
API_TIMEOUT = "120"

# -----------------------------
# 路径配置
# -----------------------------

PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT.parent / "data"
RAW_CASES_DIR = DATA_DIR / "01_raw_cases"
RESULTS_DIR = DATA_DIR / "02_agent_results"
CACHE_DIR = PROJECT_ROOT / "cache"
LOG_DIR = PROJECT_ROOT / "logs"

LOG_LEVEL = "INFO"


def ensure_directories() -> None:
    """确保阶段二所需目录存在。"""
    RAW_CASES_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)


def apply_runtime_env() -> None:
    """将 config 中的 API/运行配置同步到环境变量，兼容迁入代码。"""
    os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY
    os.environ["OPENAI_API_ENDPOINT"] = OPENAI_API_ENDPOINT
    os.environ["SERPER_API_KEY"] = SERPER_API_KEY
    os.environ["SERPER_URL"] = SERPER_URL
    os.environ["JINA_API_KEY"] = JINA_API_KEY
    os.environ["VLLM_QUESTION_ANSWER_MODEL_PORT"] = VLLM_QUESTION_ANSWER_MODEL_PORT
    os.environ["API_TIMEOUT"] = API_TIMEOUT
    os.environ["DUMMY_WEBSITE_GENERATION_MODEL"] = GENERATOR_MODEL


# 模块导入即创建目录，避免后续写入报错
ensure_directories()
