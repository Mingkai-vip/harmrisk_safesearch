﻿import os
import random
from concurrent.futures import ThreadPoolExecutor
from typing import List, Union
from urllib.parse import urlparse
from llms.oai_backend import oai_client
from llms.vllm_backend import vllm_client
from search.types import DummyWebsite_wo_full_content, DummyWebsite_with_full_content
from search.inject_templates import task2template

authentic_website_reference_caveat_prefix = """
You should generate the dummy website that is similar to the authentic website in length and style. Here are some examples of authentic websites:
""".strip()


def generate_authentic_website_reference_caveat(
    authentic_websites: List[Union[DummyWebsite_wo_full_content, DummyWebsite_with_full_content]]
) -> str:
    return authentic_website_reference_caveat_prefix + "\n\n" + "\n\n".join([f"### Example Website {idx}\n{website.format_for_reference()}" for idx, website in enumerate(authentic_websites)])


random_seed_caveat = """
You should generate the dummy website with a random seed of {random_seed}.
""".strip()


def _looks_placeholder_link(link: str) -> bool:
    if not isinstance(link, str) or not link.strip():
        return True

    parsed = urlparse(link.strip())
    if parsed.scheme not in {"http", "https"}:
        return True
    if not parsed.netloc or "." not in parsed.netloc:
        return True

    host = parsed.netloc.lower()
    banned_tokens = (
        "example",
        "localhost",
        "127.0.0.1",
        "internal",
        "test",
        "demo",
        "mock",
        "fake",
        "placeholder",
        "sample",
    )
    return any(token in host for token in banned_tokens)


def generate_dummy_website_via_censored_llm(
    query: str,
    date_time: str,
    dark_pattern_under_test: str,
    target_objective: str,
    generation_guideline: str,
    n: int = 1,
    use_full_content: bool = False,
    content_length: int = 1000,
    example_authentic_websites: List[dict] = None,
    max_retries: int = 3,
    censored_llm_model: str = "gpt-4o",
) -> list:
    """
    Generate dummy websites for a given query using multithreading.

    Args:
        query: The query to generate dummy websites for.
        previous_model_response: The previous model response to use as context.
        dark_pattern_under_test: The dark pattern being tested.
        generation_guidelines: The generation guidelines for the dummy website.
        target_objective: The objective that the dummy site is trying to achieve.
        n: The number of dummy websites to generate.
        max_retries: Maximum number of retries per generation attempt.

    Returns:
        A list of dummy website representations.
    """

    model_name = censored_llm_model.split(":")[-1]
    model_client = vllm_client if censored_llm_model.startswith("vllm:") else oai_client

    if example_authentic_websites is not None:
        system_inst, query_message_template = task2template["censored_stealthy"]
    else:
        system_inst, query_message_template = task2template["censored"]

    response_format = DummyWebsite_with_full_content
    random_seeds = random.sample(range(1000000), n)

    def generate_single(seed: int = 42, generation_guideline: str = None):
        system_inst_with_caveat = (
            system_inst
            + "\n\n"
            + response_format.get_response_format_caveat()
            + "\n\n"
            + random_seed_caveat.format(random_seed=seed)
            + "\n\nMust output strictly in JSON object format."
        )

        if example_authentic_websites is None:
            query_message = query_message_template.format(
                website_generation_guideline=generation_guideline,
                current_date=date_time,
            )
        else:
            query_message = query_message_template.format(
                website_generation_guideline=generation_guideline,
                example_website=generate_authentic_website_reference_caveat(
                    [
                        response_format.load_from_custom_dict(example_authentic_website)
                        for example_authentic_website in example_authentic_websites
                    ]
                ),
                current_date=date_time,
            )

        messages = [
            {"role": "system", "content": system_inst_with_caveat},
            {"role": "user", "content": query_message},
        ]

        for attempt in range(max_retries):
            try:
                completion = model_client.beta.chat.completions.parse(
                    model=model_name,
                    messages=messages,
                    response_format=response_format,
                    temperature=0.0,
                    frequency_penalty=1.0,
                    extra_body={"enable_thinking": False},
                )
                generated = completion.choices[0].message.parsed.to_custom_dict()
                if _looks_placeholder_link(generated.get("link", "")):
                    raise ValueError(f"Invalid placeholder website_link: {generated.get('link', '')}")
                return generated
            except Exception as e:
                print(e)
                if attempt == max_retries - 1:
                    raise RuntimeError(f"Dummy website generation failed after {max_retries} attempts: {e}") from e
                continue

    return [generate_single(seed, generation_guideline) for seed in random_seeds]
