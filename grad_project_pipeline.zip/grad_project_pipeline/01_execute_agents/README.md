﻿# 01_execute_agents (Standalone)

独立版阶段二搜索智能体执行流程。

## 目录结构

- `main.py`：阶段二入口（按 `TARGET_AGENT_TYPE` 执行单个 agent）
- `config.py`：本地固定配置（模型、路径、API、执行参数）
- `executor_with_search_agents.py`：执行器主逻辑
- `agent/`：三类 agent 及 deepmind 子模块
- `search/`：搜索与注入相关实现（含 `inject_templates/`）
- `llms/`：LLM 后端适配
- `defense/filter.py`：不可靠结果过滤器
- `../data/01_raw_cases/`：共享输入目录（来自 00 输出）
- `../data/02_agent_results/`：共享输出目录（01 结果）
- `cache/`：搜索缓存
- `logs/`：每次运行日志（`run_YYYYMMDD_HHMMSS.log`）

## 运行

在仓库根目录执行：

```bash
python grad_project_pipeline/01_execute_agents/main.py
python grad_project_pipeline/01_execute_agents/main.py --list-agents
python grad_project_pipeline/01_execute_agents/main.py --list-input-files
python grad_project_pipeline/01_execute_agents/main.py --agent sag
python grad_project_pipeline/01_execute_agents/main.py --input-file Telecom-Fraud-1.jsonl
```

## 配置

所有配置集中在 `config.py`：

- API：`OPENAI_API_KEY`、`OPENAI_API_ENDPOINT`、`SERPER_API_KEY`、`JINA_API_KEY` 等
- 执行：`TARGET_AGENT_TYPE`、并发、超时、注入参数
- 路径：`RAW_CASES_DIR`、`RESULTS_DIR`、`CACHE_DIR`、`LOG_DIR`

说明：`--input-file` 未提供时，交互终端会进入单文件选择；非交互终端会报错并要求显式指定输入文件。

说明：运行时由 `apply_runtime_env()` 将配置同步到环境变量，迁入代码不依赖 `.env` 作为配置源。
