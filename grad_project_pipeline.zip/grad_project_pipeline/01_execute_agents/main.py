﻿#!/usr/bin/env python3
"""
阶段二入口：执行搜索智能体（独立版）

运行方式:
    python grad_project_pipeline/01_execute_agents/main.py
    python grad_project_pipeline/01_execute_agents/main.py --agent sag
    python grad_project_pipeline/01_execute_agents/main.py --list-input-files
    python grad_project_pipeline/01_execute_agents/main.py --input-file Telecom-Fraud-1.jsonl
"""

import argparse
import logging
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List

from config import (
    TARGET_AGENT_MODELS,
    AVAILABLE_AGENT_TYPES,
    TARGET_AGENT_TYPE,
    GENERATOR_MODEL,
    AGENTS_TO_EXCLUDE,
    MAX_RETRIES,
    EXECUTION_MAX_WORKERS,
    CURRENT_TIME,
    WEBSITE_SORT_METHOD,
    MAX_WEBSITE_TOKEN_LENGTH,
    N_RETURNED_WEBSITES,
    N_INJECTED,
    INJECTION_MODE,
    MAX_SEARCHES,
    MAX_RESEARCH_LOOPS,
    MAX_QUERIES_PER_TURN,
    WITH_REMINDER,
    NUM_REPETITIONS,
    TIMEOUT_PER_TASK,
    DEBUG_MODE,
    NO_URL,
    USE_EXAMPLE_AUTHENTIC_WEBSITES,
    HF_DATASET_NAME,
    HF_DATASET_CONFIG,
    TOKENIZER_DIR,
    TEMPERATURE,
    MAX_COMPLETION_TOKENS,
    TOP_P,
    REASONING_EFFORT,
    DISABLE_THINKING,
    SAVE_COMBINED_RESULTS,
    RAW_CASES_DIR,
    RESULTS_DIR,
    CACHE_DIR,
    LOG_DIR,
    LOG_LEVEL,
    ensure_directories,
    apply_runtime_env,
)


def setup_logging() -> tuple[logging.Logger, str]:
    """初始化控制台+文件日志。"""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file_path = LOG_DIR / f"run_{run_id}.log"

    logger = logging.getLogger("execute_agents")
    logger.handlers.clear()
    logger.propagate = False
    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logger.level)
    console_handler.setFormatter(formatter)

    file_handler = logging.FileHandler(log_file_path, encoding="utf-8")
    file_handler.setLevel(logger.level)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    return logger, str(log_file_path)


def _list_input_files(raw_cases_dir: Path) -> List[str]:
    """列出共享输入目录中的 JSONL 文件名（仅当前目录）。"""
    if not raw_cases_dir.exists():
        return []
    return sorted([p.name for p in raw_cases_dir.glob("*.jsonl") if p.is_file()])


def _interactive_select_input_file(file_names: List[str]) -> str:
    """交互式单选一个输入 JSONL 文件。"""
    print("\n可用输入文件：")
    for idx, name in enumerate(file_names, 1):
        print(f"  {idx}. {name}")

    while True:
        raw = input("请选择输入文件（输入序号或文件名）：").strip()
        if not raw:
            print("输入不能为空，请重新输入。")
            continue

        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(file_names):
                return file_names[idx - 1]
            print("序号超出范围，请重新输入。")
            continue

        if raw in file_names:
            return raw

        print("未找到该文件，请重新输入。")


@dataclass
class ExecutionConfig:
    test_case_dir: str
    test_case_file: str | None
    results_dir: str
    run_name: str
    model_name: str
    dummy_model: str

    agents_to_exclude: List[str]
    max_retries: int
    max_workers: int
    current_time: str
    cache_path: str

    website_sort_method: str
    max_website_token_length: int
    n_returned_websites: int
    n_injected: int
    injection_mode: str
    censored_llm_model: str

    max_searches: int
    max_research_loops: int
    maximal_num_of_queries_per_turn: int
    with_reminder: bool
    num_repetitions: int
    timeout_per_task: int
    debug: bool
    no_url: bool
    use_example_authentic_websites: bool

    hf_dataset_name: str | None
    hf_dataset_config: str | None
    tokenizer_dir: str | None

    temperature: float
    max_completion_tokens: int
    top_p: float
    reasoning_effort: str | None
    disable_thinking: bool



def build_execution_config(run_name: str, model_name: str, test_case_file: str | None) -> ExecutionConfig:
    return ExecutionConfig(
        test_case_dir=str(RAW_CASES_DIR),
        test_case_file=test_case_file,
        results_dir=str(RESULTS_DIR),
        run_name=run_name,
        model_name=model_name,
        dummy_model=GENERATOR_MODEL,
        agents_to_exclude=list(AGENTS_TO_EXCLUDE),
        max_retries=MAX_RETRIES,
        max_workers=EXECUTION_MAX_WORKERS,
        current_time=CURRENT_TIME,
        cache_path=str(CACHE_DIR),
        website_sort_method=WEBSITE_SORT_METHOD,
        max_website_token_length=MAX_WEBSITE_TOKEN_LENGTH,
        n_returned_websites=N_RETURNED_WEBSITES,
        n_injected=N_INJECTED,
        injection_mode=INJECTION_MODE,
        censored_llm_model=GENERATOR_MODEL,
        max_searches=MAX_SEARCHES,
        max_research_loops=MAX_RESEARCH_LOOPS,
        maximal_num_of_queries_per_turn=MAX_QUERIES_PER_TURN,
        with_reminder=WITH_REMINDER,
        num_repetitions=NUM_REPETITIONS,
        timeout_per_task=TIMEOUT_PER_TASK,
        debug=DEBUG_MODE,
        no_url=NO_URL,
        use_example_authentic_websites=USE_EXAMPLE_AUTHENTIC_WEBSITES,
        hf_dataset_name=HF_DATASET_NAME,
        hf_dataset_config=HF_DATASET_CONFIG,
        tokenizer_dir=TOKENIZER_DIR,
        temperature=TEMPERATURE,
        max_completion_tokens=MAX_COMPLETION_TOKENS,
        top_p=TOP_P,
        reasoning_effort=REASONING_EFFORT,
        disable_thinking=DISABLE_THINKING,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="执行阶段二搜索智能体评测（独立版）")
    parser.add_argument("--model", type=str, default=None, help="覆盖 config.py 中的默认 victim model")
    parser.add_argument("--agent", type=str, default=None, help="指定单个 agent，默认取 config.py TARGET_AGENT_TYPE")
    parser.add_argument("--list-agents", action="store_true", help="列出可用 agent 并退出")
    parser.add_argument("--input-file", type=str, default=None, help="指定单个输入 JSONL 文件名（位于共享 data/01_raw_cases）")
    parser.add_argument("--list-input-files", action="store_true", help="列出共享输入目录可用 JSONL 文件并退出")
    args = parser.parse_args()

    ensure_directories()
    apply_runtime_env()

    logger, log_file = setup_logging()
    logger.info("[RUN_START] log_file=%s", log_file)
    logger.info("[RUN_START] cli_args=%s", vars(args))

    target_model = args.model or TARGET_AGENT_MODELS[0]
    selected_agent = (args.agent or TARGET_AGENT_TYPE).strip()
    available_input_files = _list_input_files(RAW_CASES_DIR)

    if args.list_agents:
        print("可用 agent：")
        for agent_name in AVAILABLE_AGENT_TYPES:
            print(f"  - {agent_name}")
        return

    if args.list_input_files:
        print("可用输入文件：")
        for file_name in available_input_files:
            print(f"  - {file_name}")
        return

    if not RAW_CASES_DIR.exists():
        logger.error("[RUN_START] test case dir not found: %s", RAW_CASES_DIR)
        sys.exit(1)

    if args.input_file:
        selected_input_file = args.input_file.strip()
    else:
        if sys.stdin.isatty():
            if not available_input_files:
                logger.error("[RUN_START] no input jsonl found in %s", RAW_CASES_DIR)
                sys.exit(1)
            try:
                selected_input_file = _interactive_select_input_file(available_input_files)
            except (EOFError, KeyboardInterrupt):
                logger.error("[RUN_START] interactive selection cancelled; please use --input-file")
                sys.exit(1)
        else:
            logger.error("[RUN_START] non-interactive mode requires --input-file")
            sys.exit(1)

    selected_input_path = Path(selected_input_file)
    if not selected_input_path.is_absolute():
        selected_input_path = RAW_CASES_DIR / selected_input_file

    if not selected_input_path.exists() or not selected_input_path.is_file():
        logger.error("[RUN_START] input file not found: %s", selected_input_path)
        if available_input_files:
            logger.error("[RUN_START] available input files=%s", available_input_files)
        sys.exit(1)

    if selected_input_path.suffix.lower() != ".jsonl":
        logger.error("[RUN_START] input file must be .jsonl: %s", selected_input_path)
        sys.exit(1)

    # 延迟导入：确保 config 已先同步环境变量，且输入文件已确认
    from executor_with_search_agents import SearchAgentExecutor, _prepare_generation_args

    run_name = f"crime_audit_{int(time.time())}"
    config = build_execution_config(
        run_name=run_name,
        model_name=target_model,
        test_case_file=str(selected_input_path),
    )
    gen_args = _prepare_generation_args(config)

    logger.info(
        "[RUN_START] model=%s run_name=%s input_dir=%s input_file=%s output=%s agent=%s",
        target_model,
        run_name,
        config.test_case_dir,
        config.test_case_file,
        config.results_dir,
        selected_agent,
    )

    executor = SearchAgentExecutor(
        test_case_dir=config.test_case_dir,
        test_case_file=config.test_case_file,
        results_dir=config.results_dir,
        run_name=config.run_name,
        agents_to_exclude=config.agents_to_exclude,
        max_retries=config.max_retries,
        max_workers=config.max_workers,
        current_time=config.current_time,
        cache_path=config.cache_path,
        model_name=config.model_name,
        tokenizer_dir=config.tokenizer_dir,
        gen_args=gen_args,
        website_sort_method=config.website_sort_method,
        max_website_token_length=config.max_website_token_length,
        n_returned_websites=config.n_returned_websites,
        n_injected=config.n_injected,
        injection_mode=config.injection_mode,
        censored_llm_model=config.censored_llm_model,
        max_searches=config.max_searches,
        max_research_loops=config.max_research_loops,
        maximal_num_of_queries_per_turn=config.maximal_num_of_queries_per_turn,
        with_reminder=config.with_reminder,
        num_repetitions=config.num_repetitions,
        timeout_per_task=config.timeout_per_task,
        debug=config.debug,
        no_url=config.no_url,
        use_example_authentic_websites=config.use_example_authentic_websites,
        hf_dataset_name=config.hf_dataset_name,
        hf_dataset_config=config.hf_dataset_config,
    )

    try:
        test_cases = executor.load_test_cases()
        logger.info("[RUN_START] loaded_cases=%d", len(test_cases))

        if selected_agent not in executor.agent_registry:
            logger.error(
                "[RUN_START] unknown agent=%s available=%s",
                selected_agent,
                list(executor.agent_registry.keys()),
            )
            sys.exit(1)

        logger.info("[EXEC_START] agent=%s", selected_agent)
        start = time.time()
        results = executor.run_single_agent(selected_agent, test_cases)
        elapsed = time.time() - start
        total_results = len(results)
        failed_results = sum(
            1 for r in results
            if isinstance(r, dict) and isinstance(r.get("meta"), dict) and r["meta"].get("error")
        )
        success_results = total_results - failed_results
        logger.info(
            "[EXEC_DONE] agent=%s total=%d success=%d fail=%d elapsed=%.2fs",
            selected_agent,
            total_results,
            success_results,
            failed_results,
            elapsed,
        )

        if SAVE_COMBINED_RESULTS:
            executor.save_combined_results({selected_agent: results})
            logger.info("[RUN_SUMMARY] combined_result_saved=true")

        logger.info(
            "[RUN_SUMMARY] agent=%s total=%d success=%d fail=%d",
            selected_agent,
            total_results,
            success_results,
            failed_results,
        )

    except Exception as e:
        logger.exception("[RUN_SUMMARY] execution failed: %s", e)
        raise
    finally:
        executor.close()


if __name__ == "__main__":
    main()

